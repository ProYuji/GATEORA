import NextAuth, { type NextAuthOptions } from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';
import CredentialsProvider from 'next-auth/providers/credentials';

const providers: NextAuthOptions['providers'] = [];
if (process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET) {
  providers.push(GoogleProvider({
    clientId: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    authorization: { params: { scope: 'openid email profile', prompt: 'select_account' } }
  }));
}
// Demo login is intentionally non-production. Set DEMO_MODE=false before any public launch.
if (process.env.DEMO_MODE === 'true') {
  providers.push(CredentialsProvider({
    id: 'demo', name: 'Demo workspace', credentials: {},
    async authorize() { return { id: 'gateora-demo-user', name: 'Demo Merchant', email: 'demo@gateora.local' }; }
  }));
}

export const authOptions: NextAuthOptions = {
  providers,
  secret: process.env.NEXTAUTH_SECRET || 'local-demo-only-change-before-deploy',
  session: { strategy: 'jwt', maxAge: 60 * 60 * 8 },
  callbacks: {
    async jwt({ token, account, user }) {
      if (account?.id_token) token.googleIdToken = account.id_token;
      if (user?.id) token.sub = user.id;
      return token;
    },
    async session({ session, token }) {
      if (session.user) (session.user as typeof session.user & { id?: string }).id = token.sub;
      return session;
    }
  },
  pages: { signIn: '/login' }
};
export default NextAuth(authOptions);
