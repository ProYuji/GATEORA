'use client';
import { signOut } from 'next-auth/react';
import { LogOut } from 'lucide-react';
export function SignOutButton(){return <button title="Sign out" onClick={()=>signOut({callbackUrl:'/'})} style={{background:'transparent',border:0,color:'#7e8aa0',cursor:'pointer',padding:5}}><LogOut size={14}/></button>}
