'use client';
import Link from 'next/link';
import { signIn, useSession } from 'next-auth/react';
import { useEffect } from 'react';
import { ArrowLeft, ArrowUpRight, ShieldCheck, Sparkles } from 'lucide-react';
import { GateoraLogo } from '@/components/gateora-logo';
export default function Login(){
 const {status}=useSession(); const demo=process.env.NEXT_PUBLIC_DEMO_MODE==='true'; const google=Boolean(process.env.NEXT_PUBLIC_GOOGLE_LOGIN_ENABLED==='true');
 useEffect(()=>{if(status==='authenticated')window.location.href='/dashboard'},[status]);
 return <main className="auth-wrap"><section className="auth-art"><Link href="/" className="brand"><GateoraLogo/></Link><div><div className="eyebrow"><span className="pulse"/> YOUR PAYMENT COMMAND CENTRE</div><h1>Move payments.<br/><span className="gradient">Not complexity.</span></h1><p className="hero-copy">A focused workspace for payment operations, developer credentials and transaction intelligence.</p><div className="hero-note"><span>◈ API-first</span><span>⌁ Provider-ready</span><span>✳ Built for builders</span></div></div><div style={{fontSize:11,color:'#718099'}}>© 2026 GATEORA · PAYMENT GATEWAY</div></section><section className="auth-main"><div className="auth-card"><Link href="/" style={{display:'inline-flex',alignItems:'center',gap:7,color:'#8d98ad',fontSize:11,marginBottom:35}}><ArrowLeft size={13}/> Back to home</Link><div className="eyebrow">MERCHANT WORKSPACE</div><h2 style={{marginTop:20}}>Welcome to GATEORA.</h2><p>Sign in to open your merchant workspace and manage your developer tools.</p>
 {demo&&<button className="google-btn" onClick={()=>signIn('demo',{callbackUrl:'/dashboard'})} disabled={status==='loading'}><Sparkles size={17} style={{marginRight:9}}/> Explore interactive demo <ArrowUpRight size={14} style={{marginLeft:8}}/></button>}
 {google&&<button className="google-btn" onClick={()=>signIn('google',{callbackUrl:'/dashboard'})} disabled={status==='loading'}><span style={{fontSize:17,marginRight:9}}>G</span> Continue with Google <ArrowUpRight size={14} style={{marginLeft:8}}/></button>}
 {!demo&&!google&&<div className="notice">Preview mode is not enabled. Set <code>DEMO_MODE=true</code> to explore the dashboard, or configure Google OAuth credentials later.</div>}
 <div style={{display:'flex',gap:9,alignItems:'center',marginTop:23,color:'#7b879d',fontSize:10}}><ShieldCheck size={15} color="#75e4c2"/> {demo?'Demo workspace · No Google credentials required':'Secure sign-in'}</div><p className="auth-small">Demo data is illustrative only. Live payment processing is disabled until an authorised provider and required compliance arrangements are configured.</p></div></section></main>
}
