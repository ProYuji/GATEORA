import type { NextApiRequest, NextApiResponse } from 'next';
import { getToken } from 'next-auth/jwt';
export default async function handler(req: NextApiRequest, res: NextApiResponse) {
 if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
 const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET || 'local-demo-only-change-before-deploy' });
 if (!token) return res.status(401).json({ error: 'Sign in required' });
 if (process.env.DEMO_MODE === 'true' && token.sub === 'gateora-demo-user') return res.status(200).json({ demo: true, access_token: 'demo-session-not-for-payments' });
 const googleIdToken = token.googleIdToken;
 if (typeof googleIdToken !== 'string') return res.status(401).json({ error: 'Google sign-in required' });
 try { const upstream = await fetch(`${process.env.BACKEND_URL}/auth/google`, { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({id_token:googleIdToken}), cache:'no-store' }); const data=await upstream.json(); return res.status(upstream.status).json(data); }
 catch { return res.status(502).json({ error:'Authentication service unavailable' }); }
}
