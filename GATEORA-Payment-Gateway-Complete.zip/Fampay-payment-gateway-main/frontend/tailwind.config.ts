import type { Config } from 'tailwindcss';
const config: Config = { content: ['./app/**/*.{js,ts,jsx,tsx,mdx}','./components/**/*.{js,ts,jsx,tsx,mdx}'], theme: { extend: { colors: { ink:'#080B14', panel:'#101522', line:'#20283A', violet:'#8B7CFF', mint:'#75E4C2' } } }, plugins: [] };
export default config;
