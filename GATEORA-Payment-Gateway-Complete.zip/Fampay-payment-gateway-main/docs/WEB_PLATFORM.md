# GATEORA web platform foundation

This repository now contains a Next.js merchant portal, Google OAuth sign-in, a FastAPI backend foundation, MongoDB persistence, API-key issuance, and a provider adapter boundary. The original Telegram bot and `payment_template/` SDK are preserved.

## Important launch status

- The dashboard currently uses clearly labelled sample analytics; those figures are not live database metrics.
- Google OAuth can create a user and merchant workspace after credentials and MongoDB are configured.
- API keys can be issued by the backend. Secret values are displayed once and only SHA-256 hashes are stored.
- Payment creation intentionally fails closed with HTTP 503 until an authorised payment provider adapter is implemented and enabled.
- Gmail/IMAP verification is a reconciliation signal only. It must not independently mark a payment successful without authoritative provider/bank confirmation.
- This is a development foundation, not a licensed payment aggregator or production-certified payment system.

## Local development

### Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Set GOOGLE_CLIENT_ID, JWT_SECRET, MongoDB URI and DB name
uvicorn app.main:app --reload --port 8000
```

Swagger: http://localhost:8000/docs

### Frontend

```bash
cd frontend
npm install
cp .env.example .env.local
# Set Google OAuth client ID/secret, NEXTAUTH_SECRET and backend URLs
npm run dev
```

Frontend: http://localhost:3000

## Google OAuth setup

1. Open Google Cloud Console: https://console.cloud.google.com/ and create/select a project.
2. Configure the OAuth consent screen (External for public merchant accounts, as appropriate), app name, support email and privacy policy. Add test users while in testing mode.
3. Create Credentials → OAuth client ID → Web application.
4. Add authorised JavaScript origin `http://localhost:3000`.
5. Add authorised redirect URI `http://localhost:3000/api/auth/callback/google`.
6. Copy Client ID and Client Secret into `frontend/.env.local` as `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`.
7. Put the exact same Client ID in `backend/.env` as `GOOGLE_CLIENT_ID`; the backend validates the Google ID token audience.
8. Generate a long random `NEXTAUTH_SECRET` and a separate long random backend `JWT_SECRET`. Never commit either secret.
9. For production, add your HTTPS domain origin and callback URI in Google Cloud Console, set `NEXTAUTH_URL` to the production site, and use a managed secret store.

Google login flow: Browser → NextAuth Google OAuth → encrypted server-side session → Next.js server route forwards Google ID token → FastAPI verifies signature, issuer, expiry and audience → MongoDB upserts user and merchant → backend issues its own short-lived JWT.

## API key flow

1. Merchant signs in with Google.
2. Backend creates a user and an onboarding merchant workspace.
3. Merchant creates an API key in Dashboard → API keys.
4. The full secret is shown once. Backend stores only its SHA-256 hash.
5. Merchant sends the secret key from their server using `Authorization: Bearer sk_test_...`.
6. Every create-payment request must include a unique `Idempotency-Key`.

## API contract (initial)

- `POST /v1/auth/google` — exchange verified Google ID token for platform JWT.
- `GET /v1/me` — current user and merchant.
- `POST /v1/api-keys` — create a test/live credential (live requires future approval controls).
- `GET /v1/api-keys` — list key metadata, never secret values.
- `POST /v1/payments` — reserved for provider-backed payment creation; currently fail-closed with 503.
- `GET /v1/transactions` — merchant transaction list.
- `POST /v1/webhooks` — register HTTPS webhook endpoint.
- `GET /health` — health check.

## Before public production

- Integrate an RBI-authorised PA/acquiring bank/provider under a valid commercial and compliance arrangement. Do not pool, hold or settle customer funds without applicable authorisation.
- Implement provider-specific signed webhook verification and server-side status API polling; reconcile email only as a secondary signal.
- Implement provider adapter, refunds, settlement reconciliation, double-entry ledger, webhook outbox, retries, dead-letter handling, key revocation and merchant KYC/underwriting workflows.
- Add webhook SSRF protections (block private, loopback, link-local and metadata IP ranges; re-resolve DNS safely), payload size limits, signature rotation and replay windows.
- Add rate limiting, WAF, bot protection, audit logs, encrypted backups, disaster recovery, alerting, tracing, incident response and independent security testing.
- Add MongoDB replica set/sharding only after workload and data model are benchmarked. Use Redis streams/queues or a managed queue for async work; the current scaffold includes Redis in Compose but does not yet enqueue jobs.
- Run realistic load tests and capacity planning. No fixed codebase or single VPS can promise 10 million concurrent/active users without measured infrastructure sizing.
