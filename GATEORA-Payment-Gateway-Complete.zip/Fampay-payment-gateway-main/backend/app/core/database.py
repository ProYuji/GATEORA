from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.errors import PyMongoError
from .config import settings

client = MongoClient(settings.mongodb_uri, maxPoolSize=100, minPoolSize=5, serverSelectionTimeoutMS=5000, retryWrites=True)
db = client[settings.db_name]

def ensure_indexes() -> None:
    db.users.create_index([("google_sub", ASCENDING)], unique=True)
    db.merchants.create_index([("owner_user_id", ASCENDING)], unique=True)
    db.api_keys.create_index([("key_hash", ASCENDING)], unique=True)
    db.payments.create_index([("merchant_id", ASCENDING), ("receipt", ASCENDING)], unique=True)
    db.payments.create_index([("merchant_id", ASCENDING), ("created_at", DESCENDING)])
    db.payment_events.create_index([("provider", ASCENDING), ("event_id", ASCENDING)], unique=True, sparse=True)
    db.webhook_deliveries.create_index([("status", ASCENDING), ("next_retry_at", ASCENDING)])
