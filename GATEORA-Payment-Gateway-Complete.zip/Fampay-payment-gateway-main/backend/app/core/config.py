from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_env: str = "development"
    api_prefix: str = "/v1"
    mongodb_uri: str = "mongodb://localhost:27017"
    db_name: str = "gateora_gateway"
    google_client_id: str = ""
    jwt_secret: str = "CHANGE_ME_USE_A_LONG_RANDOM_SECRET"
    jwt_expire_minutes: int = 60
    cors_origins: str = "http://localhost:3000"
    payment_provider_enabled: bool = False
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
