import hashlib, secrets, jwt
from datetime import datetime, timedelta, timezone
from .config import settings

def issue_access_token(user_id: str, merchant_id: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {"sub": user_id, "merchant_id": merchant_id, "iat": now, "exp": now + timedelta(minutes=settings.jwt_expire_minutes), "type": "access"}
    return jwt.encode(payload, settings.jwt_secret, algorithm="HS256")

def decode_access_token(token: str) -> dict:
    return jwt.decode(token, settings.jwt_secret, algorithms=["HS256"])

def hash_secret(secret: str) -> str:
    return hashlib.sha256(secret.encode()).hexdigest()

def create_api_secret(prefix: str = "sk_test") -> str:
    return f"{prefix}_{secrets.token_urlsafe(32)}"
