from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from .core.config import settings
from .core.database import ensure_indexes
from .api.routes import router

app = FastAPI(title="GATEORA Payment Gateway API", version="1.0.0", docs_url="/docs", redoc_url="/redoc")
origins = [x.strip() for x in settings.cors_origins.split(",") if x.strip()]
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True, allow_methods=["GET", "POST", "PATCH", "DELETE"], allow_headers=["Authorization", "Content-Type", "Idempotency-Key", "X-Request-ID"])
app.include_router(router, prefix=settings.api_prefix)

@app.on_event("startup")
def startup():
    ensure_indexes()

@app.get("/health")
def health():
    return {"status": "ok", "service": "gateora-gateway-api", "environment": settings.app_env}
