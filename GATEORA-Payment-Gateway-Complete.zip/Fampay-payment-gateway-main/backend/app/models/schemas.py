from pydantic import BaseModel, Field, ConfigDict
from typing import Literal

class GoogleLoginRequest(BaseModel):
    id_token: str = Field(min_length=20)

class PaymentCreate(BaseModel):
    amount: int = Field(gt=0, le=10_000_000_00, description="Amount in paise")
    currency: Literal["INR"] = "INR"
    receipt: str = Field(min_length=1, max_length=80)
    method: Literal["upi"] = "upi"
    model_config = ConfigDict(extra="forbid")

class ApiKeyCreate(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    environment: Literal["test", "live"] = "test"

class WebhookCreate(BaseModel):
    url: str = Field(min_length=8, max_length=500)
    events: list[str] = Field(default_factory=lambda: ["payment.succeeded", "payment.failed"])
