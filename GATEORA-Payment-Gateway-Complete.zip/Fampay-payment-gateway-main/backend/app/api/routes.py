from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Header, HTTPException, status
from google.oauth2 import id_token as google_id_token
from google.auth.transport import requests as google_requests
from pymongo import ReturnDocument
from bson import ObjectId
from ..core.config import settings
from ..core.database import db
from ..core.security import issue_access_token, hash_secret, create_api_secret, decode_access_token
from ..models.schemas import GoogleLoginRequest, PaymentCreate, ApiKeyCreate, WebhookCreate

router = APIRouter()

@router.post("/auth/google")
def google_login(payload: GoogleLoginRequest):
    if not settings.google_client_id:
        raise HTTPException(503, "Google OAuth is not configured")
    try:
        identity = google_id_token.verify_oauth2_token(payload.id_token, google_requests.Request(), settings.google_client_id)
    except Exception:
        raise HTTPException(401, "Invalid or expired Google identity token")
    if not identity.get("email_verified") or not identity.get("sub"):
        raise HTTPException(401, "A verified Google account is required")
    now = datetime.now(timezone.utc)
    user = db.users.find_one_and_update(
        {"google_sub": identity["sub"]},
        {"$set": {"email": identity.get("email"), "name": identity.get("name"), "picture": identity.get("picture"), "updated_at": now}, "$setOnInsert": {"created_at": now}},
        upsert=True, return_document=ReturnDocument.AFTER
    )
    merchant = db.merchants.find_one_and_update(
        {"owner_user_id": str(user["_id"])},
        {"$setOnInsert": {"status": "onboarding", "business_name": None, "created_at": now, "mode": "test"}},
        upsert=True, return_document=ReturnDocument.AFTER
    )
    return {"access_token": issue_access_token(str(user["_id"]), str(merchant["_id"])), "token_type": "bearer", "expires_in": settings.jwt_expire_minutes * 60, "user": {"id": str(user["_id"]), "name": user.get("name"), "email": user.get("email"), "picture": user.get("picture")}, "merchant": {"id": str(merchant["_id"]), "status": merchant.get("status"), "mode": merchant.get("mode")}}

def current_identity(authorization: str | None = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Bearer token required")
    try:
        return decode_access_token(authorization.split(" ", 1)[1])
    except Exception:
        raise HTTPException(401, "Invalid or expired access token")

def merchant_from_api_key(authorization: str | None = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer sk_"):
        raise HTTPException(401, "A merchant secret API key is required")
    raw = authorization.split(" ", 1)[1]
    record = db.api_keys.find_one({"key_hash": hash_secret(raw), "revoked": False})
    if not record:
        raise HTTPException(401, "Invalid API key")
    db.api_keys.update_one({"_id": record["_id"]}, {"$set": {"last_used_at": datetime.now(timezone.utc)}})
    return record

@router.get("/me")
def me(identity=Depends(current_identity)):
    user = db.users.find_one({"_id": ObjectId(identity["sub"])}, {"google_sub": 0})
    merchant = db.merchants.find_one({"_id": ObjectId(identity["merchant_id"])})
    if not user or not merchant: raise HTTPException(404, "Account not found")
    return {"user": {"id": str(user["_id"]), "name": user.get("name"), "email": user.get("email")}, "merchant": {"id": str(merchant["_id"]), "status": merchant.get("status"), "mode": merchant.get("mode")}}

@router.post("/api-keys")
def create_api_key(payload: ApiKeyCreate, identity=Depends(current_identity)):
    merchant_id = identity["merchant_id"]
    merchant = db.merchants.find_one({"_id": ObjectId(merchant_id)})
    if payload.environment == "live" and (not merchant or merchant.get("status") != "approved"):
        raise HTTPException(403, "Live keys are available only after merchant approval and provider onboarding")
    prefix = "sk_live" if payload.environment == "live" else "sk_test"
    secret = create_api_secret(prefix)
    now = datetime.now(timezone.utc)
    result = db.api_keys.insert_one({"merchant_id": merchant_id, "name": payload.name, "environment": payload.environment, "key_hash": hash_secret(secret), "key_prefix": secret[:14], "revoked": False, "created_at": now, "last_used_at": None})
    return {"id": str(result.inserted_id), "name": payload.name, "environment": payload.environment, "secret_key": secret, "warning": "Copy this key now. It cannot be retrieved again."}

@router.delete("/api-keys/{key_id}")
def revoke_api_key(key_id: str, identity=Depends(current_identity)):
    try:
        oid = ObjectId(key_id)
    except Exception:
        raise HTTPException(400, "Invalid API key ID")
    result = db.api_keys.update_one({"_id": oid, "merchant_id": identity["merchant_id"]}, {"$set": {"revoked": True, "revoked_at": datetime.now(timezone.utc)}})
    if result.matched_count == 0:
        raise HTTPException(404, "API key not found")
    return {"id": key_id, "revoked": True}

@router.get("/api-keys")
def list_api_keys(identity=Depends(current_identity)):
    keys = db.api_keys.find({"merchant_id": identity["merchant_id"]}, {"key_hash": 0}).sort("created_at", -1)
    return [{"id": str(k["_id"]), "name": k["name"], "environment": k["environment"], "prefix": k["key_prefix"], "revoked": k["revoked"], "created_at": k["created_at"], "last_used_at": k.get("last_used_at")} for k in keys]

@router.post("/payments", status_code=202)
def create_payment(payload: PaymentCreate, idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"), key=Depends(merchant_from_api_key)):
    if not idempotency_key: raise HTTPException(400, "Idempotency-Key header is required")
    if not settings.payment_provider_enabled:
        raise HTTPException(503, "No authorised payment provider is enabled. No payment has been created or collected.")
    # Provider orchestration is intentionally fail-closed until an authorised adapter is implemented.
    raise HTTPException(503, "Payment provider adapter is not configured")

@router.get("/transactions")
def transactions(identity=Depends(current_identity), limit: int = 50):
    limit = max(1, min(limit, 100))
    cursor = db.payments.find({"merchant_id": identity["merchant_id"]}, {"_id": 0}).sort("created_at", -1).limit(limit)
    return list(cursor)

@router.post("/webhooks")
def create_webhook(payload: WebhookCreate, identity=Depends(current_identity)):
    if not payload.url.startswith("https://"):
        raise HTTPException(400, "Webhook URLs must use HTTPS")
    # Production must additionally block private, loopback and link-local destinations and revalidate DNS on delivery.
    result = db.webhook_endpoints.insert_one({"merchant_id": identity["merchant_id"], "url": payload.url, "events": payload.events, "enabled": True, "created_at": datetime.now(timezone.utc)})
    return {"id": str(result.inserted_id), "url": payload.url, "events": payload.events, "enabled": True}
