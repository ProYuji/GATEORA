# GATEORA — Payment Gateway web preview

This repository contains a GATEORA-branded Next.js merchant portal, a FastAPI backend foundation, and the original Telegram bot/payment-template source. The current preview is designed to run on Vercel without Google OAuth credentials or a live payment provider.

## Preview locally

Requirements: Node.js 20+ and npm.

```bash
cd frontend
cp .env.example .env.local
# Set NEXTAUTH_SECRET to a random long secret
npm install
npm run dev
```

Open http://localhost:3000. With `DEMO_MODE=true` and `NEXT_PUBLIC_DEMO_MODE=true`, use **Explore interactive demo**. Demo API keys are stored only in browser localStorage; they are not valid credentials and do not authenticate API calls. Demo transaction values are illustrative.

## Deploy frontend preview to Vercel

1. Push this repository to GitHub.
2. Import it at https://vercel.com/new.
3. Set **Root Directory** to `frontend`.
4. Framework: Next.js. Build command: `npm run build`. Install command: `npm install`.
5. Add environment variables for Production, Preview and Development:
   - `NEXTAUTH_SECRET`: a long random secret (generate with `openssl rand -base64 32`).
   - `NEXTAUTH_URL`: your Vercel preview URL, e.g. `https://your-project.vercel.app`.
   - `DEMO_MODE`: `true`.
   - `NEXT_PUBLIC_DEMO_MODE`: `true`.
   - `NEXT_PUBLIC_GOOGLE_LOGIN_ENABLED`: `false`.
6. Deploy. No Google Client ID, Google Client Secret, MongoDB or backend URL is needed for the visual demo.

When you later configure Google OAuth, add `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, set `NEXT_PUBLIC_GOOGLE_LOGIN_ENABLED=true`, and set the authorized redirect URI to `https://YOUR-DOMAIN/api/auth/callback/google` in Google Cloud Console. Turn off demo mode for real user accounts.

## Backend foundation (separate host later)

```bash
cd backend
cp .env.example .env
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Configure a MongoDB URI and a strong JWT secret before exposing it. The backend includes Google identity verification, merchant records, hashed API-key storage, webhook endpoint registration and fail-closed payment routes. Payment creation intentionally returns 503 until an authorised provider adapter is implemented and configured.

## Important status / limitations

- This is a design and integration preview, not a live payment aggregator or production-ready payment processor.
- No live payment collection, settlement, refund execution or merchant payouts are enabled.
- The original `bot.py` and `payment_template/` are preserved as source; they are not automatically wired into the web app.
- Demo login is only for preview. Do not enable it for a public production deployment.
- Production scale claims require provider contracts, compliance review, threat modelling, infrastructure sizing, load tests, backups and operational monitoring. No 10-million-user capacity is claimed or guaranteed by this starter.
