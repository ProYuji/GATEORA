# Vercel preview quick deploy

**Root Directory:** `frontend`  
**Framework:** Next.js  
**Build:** `npm run build`  
**Install:** `npm install`

Set these Vercel Environment Variables:

```env
NEXTAUTH_SECRET=<generate-a-long-random-secret>
NEXTAUTH_URL=https://YOUR-PROJECT.vercel.app
DEMO_MODE=true
NEXT_PUBLIC_DEMO_MODE=true
NEXT_PUBLIC_GOOGLE_LOGIN_ENABLED=false
```

No Google OAuth credentials, backend URL, MongoDB or payment provider is needed to preview the website. Visit `/login` and click **Explore interactive demo**.

This demo is for design review only. Demo API keys are browser-local placeholders and do not work against a payment API. The backend payment route is intentionally fail-closed until a real authorised payment provider is integrated.
